<?php
defined( 'ABSPATH' ) || exit;

/**
 * Plugin settings: frontend URL, revalidation token, contact email.
 * Stored in wp_options.
 */
class Adil_Settings {

    public static function init(): void {
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
    }

    public static function register_settings(): void {
        register_setting( 'adil_settings_group', 'adil_frontend_url',     [ 'sanitize_callback' => 'esc_url_raw',         'default' => 'https://adilashrafi.com' ] );
        register_setting( 'adil_settings_group', 'adil_contact_email',    [ 'sanitize_callback' => 'sanitize_email',      'default' => get_option( 'admin_email' ) ] );
        register_setting( 'adil_settings_group', 'adil_revalidate_token', [ 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ] );

        // Site meta fields
        register_setting( 'adil_settings_group', 'adil_site_title',                [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'Al Adil Ashrafi' ] );
        register_setting( 'adil_settings_group', 'adil_site_tagline',              [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'The Marketing Alchemist' ] );
        register_setting( 'adil_settings_group', 'adil_site_bio',                  [ 'sanitize_callback' => 'wp_kses_post',        'default' => '' ] );
        register_setting( 'adil_settings_group', 'adil_site_location',             [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'Mohammadpur, Dhaka, Bangladesh' ] );
        register_setting( 'adil_settings_group', 'adil_site_email',                [ 'sanitize_callback' => 'sanitize_email',      'default' => 'hello@adilashrafi.com' ] );
        register_setting( 'adil_settings_group', 'adil_site_linkedin',             [ 'sanitize_callback' => 'esc_url_raw',         'default' => 'https://linkedin.com/in/aladilashrafisaikat' ] );
        register_setting( 'adil_settings_group', 'adil_site_availability',         [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'Available for Freelance' ] );
        register_setting( 'adil_settings_group', 'adil_hero_stat_roas',            [ 'sanitize_callback' => 'sanitize_text_field', 'default' => '6.5×' ] );
        register_setting( 'adil_settings_group', 'adil_hero_stat_roas_sub',        [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'ROAS — Gulf Coast Marine · 90 Days' ] );
        register_setting( 'adil_settings_group', 'adil_hero_stat_ventures',        [ 'sanitize_callback' => 'sanitize_text_field', 'default' => '3' ] );
        register_setting( 'adil_settings_group', 'adil_hero_stat_ventures_sub',    [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'Mediusware · Markimist · Bangla Track' ] );
        register_setting( 'adil_settings_group', 'adil_cta_primary_label',         [ 'sanitize_callback' => 'sanitize_text_field', 'default' => "Let's Work →" ] );
        register_setting( 'adil_settings_group', 'adil_cta_primary_href',          [ 'sanitize_callback' => 'sanitize_text_field', 'default' => '#contact' ] );
        register_setting( 'adil_settings_group', 'adil_cta_secondary_label',       [ 'sanitize_callback' => 'sanitize_text_field', 'default' => 'View Resume' ] );
        register_setting( 'adil_settings_group', 'adil_cta_secondary_href',        [ 'sanitize_callback' => 'esc_url_raw',         'default' => 'https://adilashrafi.com/resume/' ] );
    }

    /**
     * Returns all settings as a structured array for the REST /settings endpoint.
     */
    public static function get_all(): array {
        return [
            'title'                   => get_option( 'adil_site_title',             'Al Adil Ashrafi' ),
            'tagline'                 => get_option( 'adil_site_tagline',            'The Marketing Alchemist' ),
            'bio'                     => get_option( 'adil_site_bio',                '' ),
            'location'                => get_option( 'adil_site_location',           'Mohammadpur, Dhaka, Bangladesh' ),
            'email'                   => get_option( 'adil_site_email',              'hello@adilashrafi.com' ),
            'linkedin'                => get_option( 'adil_site_linkedin',           'https://linkedin.com/in/aladilashrafisaikat' ),
            'availability'            => get_option( 'adil_site_availability',       'Available for Freelance' ),
            'hero_stat_roas'          => get_option( 'adil_hero_stat_roas',          '6.5×' ),
            'hero_stat_roas_sub'      => get_option( 'adil_hero_stat_roas_sub',      'ROAS — Gulf Coast Marine · 90 Days' ),
            'hero_stat_ventures'      => get_option( 'adil_hero_stat_ventures',      '3' ),
            'hero_stat_ventures_sub'  => get_option( 'adil_hero_stat_ventures_sub',  'Mediusware · Markimist · Bangla Track' ),
            'cta_primary_label'       => get_option( 'adil_cta_primary_label',       "Let's Work →" ),
            'cta_primary_href'        => get_option( 'adil_cta_primary_href',        '#contact' ),
            'cta_secondary_label'     => get_option( 'adil_cta_secondary_label',     'View Resume' ),
            'cta_secondary_href'      => get_option( 'adil_cta_secondary_href',      'https://adilashrafi.com/resume/' ),
        ];
    }
}
